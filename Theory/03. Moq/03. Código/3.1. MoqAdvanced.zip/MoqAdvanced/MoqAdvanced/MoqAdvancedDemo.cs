using Moq;
using Moq.Protected;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace MoqAdvanced
{
    public class MoqAdvancedDemo
    {
        public interface IFoo
        {
            int GetCount();
            bool IsValid<T>(T arg);
        }

        [Fact]
        public void TestMockBehaviour()
        {
            var mockDefault = new Mock<IFoo>();
            var mockStrict = new Mock<IFoo>(MockBehavior.Strict);
            var mockLoose = new Mock<IFoo>(MockBehavior.Loose);

            Assert.Throws<MockException>(() => mockStrict.Object.GetCount());
            Assert.Equal(0, mockDefault.Object.GetCount());
            Assert.Equal(0, mockLoose.Object.GetCount());
        }

        public interface IParentFoo
        {
            IFoo getFoo();
            string getError();
        }


        [Fact]
        public void TestMockBehaviourWClases()
        {
            var mockStrict = new Mock<IParentFoo>(MockBehavior.Strict);
            var mockLoose = new Mock<IParentFoo>(MockBehavior.Loose);

            Assert.Throws<MockException>(() => mockStrict.Object.getFoo());
            Assert.Throws<MockException>(() => mockStrict.Object.getError());

            var foo = mockLoose.Object.getFoo();
            Assert.Null(foo);

            var mockWDefaultMock = new Mock<IParentFoo>() { DefaultValue = DefaultValue.Mock };
            var fooMock = mockWDefaultMock.Object.getFoo();
            Assert.NotNull(fooMock);

            var mockWDefaultCustom = new Mock<IParentFoo>()
            {
                DefaultValueProvider = new MyEmptyDefaultValueProvider()
            };
            var fooCustom = mockWDefaultCustom.Object.getFoo();
            Assert.NotNull(fooCustom);
            Assert.Equal(10, fooCustom.GetCount());
        }

        class MyEmptyDefaultValueProvider : LookupOrFallbackDefaultValueProvider
        {
            public MyEmptyDefaultValueProvider()
            {
                base.Register(typeof(string), (type, mock) => "Empty string");
                base.Register(typeof(List<>), (type, mock) => Activator.CreateInstance(type));
                base.Register(typeof(IFoo), (type, mock) =>
                {
                    Mock<IFoo> fooM = new Mock<IFoo>();
                    fooM.Setup(m => m.GetCount()).Returns(10);
                    return fooM.Object;
                });
            }
        }

        public abstract class FooClass
        {
            public int GetDemoMethod() => DemoMethod("asdf");
            protected abstract int DemoMethod(string fooParam);
        }


        [Fact]
        public void TestProtectedMocks()
        {
            var mock = new Mock<FooClass>();
            mock.Protected()
                .Setup<int>("DemoMethod", ItExpr.IsAny<string>())
                .Returns(1234);

            var obj = mock.Object;
            Assert.Equal(1234, obj.GetDemoMethod());
        }

        [Fact]
        public void TestGenericTypes()
        {
            var anonymous = new { a = 0 };
            //This will fail
            //anonymous.a = 3;

            var valueTuple = (a: 0, b: "");
            valueTuple.a = 3;

            var mock = new Mock<IFoo>();
            mock.Setup(m => m.IsValid(It.IsAny<string>())).Returns(true);
            Assert.True(mock.Object.IsValid(""));
            mock.Setup(m => m.IsValid(It.IsAny<It.IsValueType>())).Returns(true);
            Assert.True(mock.Object.IsValid(0));
            mock.Setup(m => m.IsValid(It.IsAny<It.IsAnyType>())).Returns(true);
            Assert.True(mock.Object.IsValid(0));
            Assert.True(mock.Object.IsValid(""));
            mock.Setup(m => m.IsValid(It.IsAny<It.IsSubtype<object>>())).Returns(true);
            Assert.True(mock.Object.IsValid(0.0m));
        }

        [Fact]
        public void TestMockRepository()
        {
            var mockRepository = new MockRepository(MockBehavior.Default);

            var foo = mockRepository.Create<IFoo>(MockBehavior.Default);
            foo.Setup(m => m.GetCount()).Returns(1);

            var fooObj = mockRepository.Of<IFoo>().FirstOrDefault();
            Assert.NotEqual(foo.Object, fooObj);

            var foo2 = mockRepository.OneOf<IParentFoo>();
            Mock.Get(foo2).Setup(m => m.getError()).Returns("asdf");
        }
    }
}
