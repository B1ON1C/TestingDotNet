﻿using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace MoqBasics
{
    public class MoqBasics
    {
        public interface IFoo
        {
            int GetCount();
            string ToUpperCase(string v);
            int GetNextNumber();
            string DemoProperty { get; set; }
            event MyEventHandler FooEvent;
        }
        public delegate void MyEventHandler(int i, bool b);

        [Fact]
        public void DemoTest()
        {
            // Creamos el mock sobre nuestra interfaz
            var mock = new Mock<IFoo>();

            // Definimos el comportamiento del método GetCount y su resultado
            mock.Setup(m => m.GetCount()).Returns(1);

            // Creamos una instancia del objeto mockeado y la testeamos
            Assert.Equal(1, mock.Object.GetCount());
        }

        [Fact]
        public void DemoTest2()
        {
            // Creamos el mock sobre nuestra interfaz
            var mock = new Mock<IFoo>();

            // Definimos el comportamiento del método
            mock.Setup(m => m.ToUpperCase(It.IsAny<string>()))
            .Returns((string value) => { return value.ToUpperInvariant(); });

            // Definimos un comportamiento específico con parameter-matching
            mock.Setup(m => m.ToUpperCase("NotOK")).Returns("notok");

            // Obtenemos una instancia del objeto mockeado
            var mockObject = mock.Object;

            // Comprobamos el comportamiento genérico
            Assert.Equal("OK", mockObject.ToUpperCase("ok"));

            // Comprobamos que al pasar "NotOK" no lo devolvemos en mayúsculas
            Assert.NotEqual("NOTOK", mock.Object.ToUpperCase("NotOK"));
        }

        [Fact]
        public void DemoTest3()
        {
            // Creamos el mock sobre nuestra interfaz
            var mock = new Mock<IFoo>();
            int calls = 0;

            // Podemos definir callbacks de manera muy simple
            mock.Setup(m => m.ToUpperCase(It.IsAny<string>()))
            .Returns((string value) => { return value.ToUpperInvariant(); })
            .Callback(() => { calls++; });

            // Esta línea lanzará la excepción definida arriba
            Assert.Equal("EXCEPTION", mock.Object.ToUpperCase("Exception"));

            // Llamamos una vez más al método
            Assert.Equal("OK", mock.Object.ToUpperCase("ok"));

            // Comprobamos que se ha ejecutado el callback
            Assert.Equal(2, calls);
        }


        [Fact]
        public void DemoTest4()
        {
            // Creamos el mock sobre nuestra interfaz
            var mock = new Mock<IFoo>();

            mock.Setup(m => m.ToUpperCase("asdf")).Returns("ASDF");

            Assert.Equal("ASDF", mock.Object.ToUpperCase("asdf"));

            mock.Setup(m => m.ToUpperCase("asdf")).Returns("QWER");

            Assert.Equal("QWER", mock.Object.ToUpperCase("asdf"));

            var result = mock.Object.ToUpperCase("hola mundo");
            Assert.Equal("QWER", mock.Object.ToUpperCase("hola mundo"));
        }

        [Fact]
        public void DemoTest5()
        {
            var mock = new Mock<IFoo>(MockBehavior.Strict);

            mock.SetupSequence(m => m.GetNextNumber())
                .Returns(1)
                .Returns(2)
                .Returns(3)
                .Returns(4)
                .Returns(5);

            var foo = mock.Object;
            var a1 = foo.GetNextNumber();
            var a2 = foo.GetNextNumber();
            var a3 = foo.GetNextNumber();
            var a4 = foo.GetNextNumber();
            var a5 = foo.GetNextNumber();
            var a6 = foo.GetNextNumber();
            var a7 = foo.GetNextNumber();
        }
        [Fact]
        public void DemoTest5_2()
        {
            var mock = new Mock<IFoo>();
            mock.Setup(m => m.ToUpperCase("asdf")).Returns("ASDF");
            var a = mock.Object.ToUpperCase("qwer");
            var mockStrict = new Mock<IFoo>(MockBehavior.Strict);
            mockStrict.Setup(m => m.ToUpperCase("asdf")).Returns("ASDF");
            var b = mockStrict.Object.ToUpperCase("qwer");
        }

        [Fact]
        public void DemoTest5_3()
        {
            var mock = new Mock<IFoo>();
            mock.Setup(m => m.ToUpperCase(It.IsAny<string>())).Returns("ASDF");
            var a = mock.Object.ToUpperCase("qwer");
            var mockStrict = new Mock<IFoo>(MockBehavior.Strict);
            mockStrict.Setup(m => m.ToUpperCase(It.IsAny<string>())).Returns("ASDF");
            var b = mockStrict.Object.ToUpperCase("qwer");
        }

        [Fact]
        public void DemoTest6()
        {
            var mock = new Mock<IFoo>();

            mock.Setup(m => m.DemoProperty).Returns("DemoProperty");

            mock.Verify(m => m.DemoProperty, Times.Never);

            mock.Object.DemoProperty = "a";
            var a = mock.Object.DemoProperty;

            mock.Verify(m => m.DemoProperty, Times.Once);

            mock.SetupSet(m => m.DemoProperty = "asdf");
            mock.SetupGet(m => m.DemoProperty).Returns("DemoProperty");

            

            mock.Object.DemoProperty = "a";
            var b = mock.Object.DemoProperty;
            mock.Verify(m => m.DemoProperty, Times.Exactly(2));


            mock.SetupProperty(m => m.DemoProperty, "DemoProperty");
            var c = mock.Object.DemoProperty;
            mock.Object.DemoProperty = "a";
            var d = mock.Object.DemoProperty;

            mock.Verify(m => m.DemoProperty, Times.Exactly(4));

            mock.SetupAllProperties();
        }

        [Fact]
        public void DemoTest7()
        {
            var mock = new Mock<IFoo>();

            // Setting up an event's `add` and `remove` accessors (requires Moq 4.13 or later):
            mock.SetupAdd(m => m.FooEvent += It.IsAny<MyEventHandler>());
            mock.SetupRemove(m => m.FooEvent -= It.IsAny<MyEventHandler>());

            // Raise passing the custom arguments expected by the event delegate
            mock.Raise(foo => foo.FooEvent += null, 25, true);
        }

        [Fact]
        public void DemoMoqDatabase()
        {
            var db = new MockDatabaseFixtureWMoq();
            db.Db.BeginTransaction(System.Data.IsolationLevel.ReadCommitted);
            db.Db.BeginTransaction(System.Data.IsolationLevel.RepeatableRead);
            db.Db.BeginTransaction(System.Data.IsolationLevel.Chaos);
        }
    }
}
