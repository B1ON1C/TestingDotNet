﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moq.xUnitAdvancedSamples__with_Moq_
{
    public class MockDbConnection : IDbConnection
    {
        public MockDbConnection() { }

        public MockDbConnection(string cn) {
            this.ConnectionString = cn;
        }

        public string ConnectionString { get; set; }

        public int ConnectionTimeout => throw new NotImplementedException();

        public string Database => throw new NotImplementedException();

        public ConnectionState State => throw new NotImplementedException();

        public IDbTransaction BeginTransaction()
        {
            throw new NotImplementedException();
        }

        private static int concurrentTransactions = 0;
        public IDbTransaction BeginTransaction(IsolationLevel il)
        {
            concurrentTransactions++;
            if (concurrentTransactions > 100)
                throw new InsufficientMemoryException();

            switch (il)
            {
                case IsolationLevel.Unspecified:
                    return new MockDbTransaction(IsolationLevel.Serializable);
                case IsolationLevel.Chaos:
                    throw new NotSupportedException();
                case IsolationLevel.ReadUncommitted:
                    return null;
                case IsolationLevel.ReadCommitted:
                    return null;
                case IsolationLevel.RepeatableRead:
                    return new MockDbTransaction(IsolationLevel.Serializable);
                case IsolationLevel.Serializable:
                    return new MockDbTransaction(IsolationLevel.Serializable);
                case IsolationLevel.Snapshot:
                    return null;
                default:
                    throw new NotSupportedException(); 
            }
        }

        public void Open()
        {

        }

        public void Close()
        {
            concurrentTransactions--;
        }


        public void ChangeDatabase(string databaseName)
        {
            throw new NotImplementedException();
        }


        public IDbCommand CreateCommand()
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

    }
}
