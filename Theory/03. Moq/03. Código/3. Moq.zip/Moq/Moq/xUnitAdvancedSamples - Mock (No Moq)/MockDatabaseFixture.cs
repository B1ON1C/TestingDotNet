﻿using Moq.xUnitAdvancedSamples__with_Moq_;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Xunit;

namespace Moq
{
    public class MockDatabaseFixture : IDisposable
    {
        private const string cn = "DummyConnection";
        public IDbConnection Db { get; private set; }

        public MockDatabaseFixture()
        {
            Db = new MockDbConnection(cn);

            // ... initialize data in the test database ...
            Db.Open();
        }

        public void Dispose()
        {
            // ... clean up test data from the database ...
            Db.Close();
            Db.Dispose();
        }
    }
}
