﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moq.xUnitAdvancedSamples__with_Moq_
{
    public class MockDbTransaction : IDbTransaction
    {
        public MockDbTransaction() { }

        public MockDbTransaction(IsolationLevel lvl)
        {
            isolationLevel = lvl;
        }
        public IDbConnection Connection => new MockDbConnection();

        private IsolationLevel isolationLevel;
        public IsolationLevel IsolationLevel => isolationLevel;

        public void Commit()
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public void Rollback()
        {
            throw new NotImplementedException();
        }
    }
}
