﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using xUnitAdvanced.Utils;

namespace xUnitAdvanced
{
    public class EmployeesWBaseEntityTest : BaseEntityTest, IClassFixture<DatabaseFixture>
    {
        private readonly List<EmployeeEntity> listEmployees;
        public EmployeesWBaseEntityTest(DatabaseFixture databaseFixture) : 
                base(databaseFixture) {
            listEmployees = new List<EmployeeEntity>();
            for (int i = 0; i < 50; i++)
            {
                listEmployees.Add(new EmployeeEntity()
                {
                    LoginID = $"Usuario {i}",
                    Gender = i % 2 == 0 ? 'M' : 'F'
                });
            }
        }

        protected override string tableName => "HumanResources.Employee";


        private readonly char[] ValidGenders = { 'M', 'F' };

        [Fact]
        public void Employees_CheckGenders_OnlyMFValues()
        {
            Assert.All(listEmployees, e => 
                Assert.Contains(e.Gender, ValidGenders)
            );
        }

        private readonly DateTime MIN_BIRTH_DATE = new DateTime(1930, 1, 1);

        [Fact]
        public void Employees_CheckBirthDates_YoungerThan1930()
        {
            Assert.All(listEmployees, e => 
                Assert.True(e.BirthDate >= MIN_BIRTH_DATE)
            );
        }
    }
}
