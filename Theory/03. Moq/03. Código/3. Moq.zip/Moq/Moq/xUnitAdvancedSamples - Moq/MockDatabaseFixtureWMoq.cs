﻿using Moq.xUnitAdvancedSamples__with_Moq_;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Xunit;

namespace Moq
{
    public class MockDatabaseFixtureWMoq : IDisposable
    {
        public IDbConnection Db { get; private set; }

        private static int concurrentTransactions = 0;

        public MockDatabaseFixtureWMoq()
        {
            var mockDb = new Mock<IDbConnection>();
            //With this behaviour, mock will fail when methods are not explicitly defined
            //var mockDb = new Mock<IDbConnection>(MockBehavior.Strict);

            Func<IsolationLevel, IDbTransaction> func = (il) =>
            {
                if (concurrentTransactions > 100)
                    throw new InsufficientMemoryException();

                switch (il)
                {
                    case IsolationLevel.Unspecified:
                        return new Mock<IDbTransaction>(IsolationLevel.Serializable).Object;
                    case IsolationLevel.Chaos:
                        throw new NotSupportedException();
                    case IsolationLevel.ReadUncommitted:
                        return null;
                    case IsolationLevel.ReadCommitted:
                        return null;
                    case IsolationLevel.RepeatableRead:
                        return new Mock<IDbTransaction>(IsolationLevel.Serializable).Object;
                    case IsolationLevel.Serializable:
                        return new Mock<IDbTransaction>(IsolationLevel.Serializable).Object;
                    case IsolationLevel.Snapshot:
                        return null;
                    default:
                        throw new NotSupportedException();
                }
            };
            mockDb.Setup(db => db.BeginTransaction(It.IsAny<IsolationLevel>()))
                .Returns(func)
                .Callback(() => concurrentTransactions++);

            Db = mockDb.Object;

            //This approach is valid only for classes, not interfaces (constructor doesn't allow this for interfaces)
            //var mockDb2 = new Mock<IDbConnection>();
            //mockDb2.Setup(db => db.BeginTransaction(IsolationLevel.Unspecified)).Returns(new Mock<IDbTransaction>(IsolationLevel.Serializable).Object);
            //mockDb2.Setup(db => db.BeginTransaction(IsolationLevel.Chaos)).Throws(new NotSupportedException());
            //mockDb2.Setup(db => db.BeginTransaction(IsolationLevel.ReadUncommitted)).Returns(null as IDbTransaction);
            //mockDb2.Setup(db => db.BeginTransaction(IsolationLevel.ReadCommitted)).Returns(null as IDbTransaction);
            //mockDb2.Setup(db => db.BeginTransaction(IsolationLevel.RepeatableRead)).Returns(new Mock<IDbTransaction>(IsolationLevel.Serializable).Object);
            //mockDb2.Setup(db => db.BeginTransaction(IsolationLevel.Serializable)).Returns(new Mock<IDbTransaction>(IsolationLevel.Serializable).Object);
            //mockDb2.Setup(db => db.BeginTransaction(IsolationLevel.Snapshot)).Returns(null as IDbTransaction);
            //Last configuration of same mock will be the valid one
            //mockDb2.Setup(db => db.BeginTransaction(IsolationLevel.Snapshot)).Returns(null as IDbTransaction);

            //Db = mockDb2.Object;

            var mockDb3 = new Mock<IDbConnection>(MockBehavior.Strict);
            var dbSequence = new MockSequence();
            mockDb3.Setup(m => m.Open());
            mockDb3.Setup(m => m.CreateCommand()).Returns(new Mock<IDbCommand>().Object);
            mockDb3.Setup(m => m.Close());

            mockDb3.InSequence(dbSequence).Setup(db => db.Open());
            mockDb3.InSequence(dbSequence).Setup(db => db.CreateCommand());
            mockDb3.InSequence(dbSequence).Setup(db => db.Close());

            //With this behaviour, only the steps defined IN THAT ORDER will be valid (else, will throw exception)
            //Db = mockDb3.Object;
            
            // ... initialize data in the test database ...
            Db.Open();

        }

        public void Dispose()
        {
            // ... clean up test data from the database ...
            Db.Close();
            Db.Dispose();
        }
    }
}
