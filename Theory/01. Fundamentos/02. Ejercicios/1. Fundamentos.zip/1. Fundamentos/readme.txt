En este módulo encontrarás:
- "1. Fundamentos.pdf": La teoría de fundamentos de testing explicada en clase
- "PruebasCajaNegra.xlsx": El enunciado y plantilla para realizar el análisis de pruebas de caja negra. Ver ejercicios a realizar.



Los ejercicios a realizar en este módulo son los siguientes:

- Sobre "PruebasCajaNegra.xlsx", completa las tablas de clases de equivalencia y los casos de prueba (no olvides el análisis de valores límite). Son 3 ejercicios diferentes: los 2 primeros sirven como ejemplo de cómo ir completando esta información (puedes comprobar que todos los casos estén cubiertos, y completar los que no); el ejercicio 3 supondrá realizar este mismo proceso por tu cuenta :-]

- Sobre el proyecto de referencia "Ssid.Arquitectura", identifica métodos y/o clases que sirvan de ejemplo de los diferentes principios SOLID, así como de los principios DRY (Don't Repeat Yourself) y KISS (Keep It Simple). Dichos ejemplos pueden ser tanto de casos donde se esté rompiendo el principio en cuestión (e.g. se está haciendo copy/paste en lugar de crear un método, de forma que no se respeta el principio DRY), como de casos en que sí se esté aplicando correctamente.